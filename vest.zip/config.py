BOT_TOKEN="7009502231:AAElPUKHmgrvjvcUqCju6pBNu84qrATW9Lg"
owner_id=6953639809
admin_id=6953639809
log_group=-1002054728843
orig_channel=-1002054728843
QIWI_TOKEN='eyJ2ZXJzaW9uIjoiUDJQIiwiZGF0YSI6eyJwYXlpbl9tZXJjaGFudF9zaXRlX3VpZCI6IjFyc3QweS0wMCIsInVzZXJfaWQiOiI5OTY3MDU0NDkxMTEiLCJzZWNyZXQiOiIzMDMyNGQwMGEyMDgwOTA5NDlhMTk2OTIxNDJkNThlMGVkMmM5MDZhMGQ1MTVkYzIzOTliMTVhNGFiN2Y5OGE0In19'
channell=-1002343450670
bot_name = "vest_game_bot" 

start_money = 1000000
cash_family = 5

owner = '<a href="https://t.me/pohuyu18">@admin</a>'
channel = '<a href="https://t.me/vest_channel">VEST | DEV </a>'
chat = '<a href="https://t.me/vest_shat">VEST | CHAT</a>'
chat_id=2343450670
kal = '👾 Канал с промокодами👾'
kall = '<a href="t.me/vest_channel">Нажми чтобы активировать</a>'
reg_chat_name_max = 15